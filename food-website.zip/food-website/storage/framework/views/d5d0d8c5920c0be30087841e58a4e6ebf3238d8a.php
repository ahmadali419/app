<?php echo $__env->make('front.theme.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section class="favourite">
    <div class="container">
        <h2 class="sec-head">My Favourites</h2>
        <div class="row">
            <?php if(count($favorite) == 0): ?>
                <p>No Data found</p>
            <?php else: ?> 
                <?php $__currentLoopData = $favorite; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 col-md-6">
                    <div class="pro-box">
                        <div class="pro-img">
                            <a href="<?php echo e(URL::to('product-details/'.$item->id)); ?>">
                                <img src='<?php echo e($item["itemimage"]->image); ?>' alt="">
                            </a>
                            <i class="fas fa-heart i" onclick="Unfavorite('<?php echo e($item->id); ?>','<?php echo e(Session::get('id')); ?>')"></i>
                        </div>
                        <div class="product-details-wrap">
                            <div class="product-details">
                                <a href="<?php echo e(URL::to('product-details/'.$item->id)); ?>">
                                    <h4><?php echo e($item->item_name); ?></h4>
                                </a>
                                <p class="pro-pricing"><?php echo env('CURRENCY'); ?><?php echo e(number_format($item->item_price, 2)); ?></p>
                            </div>
                            <div class="product-details">
                                <p><?php echo e(Str::limit($item->item_description, 60)); ?></p>
                                <!-- <?php if(Session::get('id')): ?>
                                    <button class="btn" onclick="AddtoCart('<?php echo e($item->id); ?>','<?php echo e(Session::get('id')); ?>')">Add to Cart</button>
                                <?php else: ?>
                                    <a class="btn" href="<?php echo e(URL::to('/signin')); ?>">Add to Cart</a>
                                <?php endif; ?> -->
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
        <?php echo $favorite->links(); ?>

    </div>
</section>

<?php echo $__env->make('front.theme.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/food/resources/views/front/favorite.blade.php ENDPATH**/ ?>