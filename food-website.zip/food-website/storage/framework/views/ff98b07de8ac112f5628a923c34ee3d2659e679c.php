
<?php $__env->startSection('content'); ?>

<!-- Updated stylesheet url -->
<link rel="stylesheet" href="https://jonthornton.github.io/jquery-timepicker/jquery.timepicker.css">
<style type="text/css">
	.ui-timepicker-wrapper {
	    overflow-y: auto;
	    max-height: 150px;
	    width: 200px;
	    background: #fff;
	    border: 1px solid #ddd;
	    -webkit-box-shadow: 0 5px 10px rgba(0,0,0,0.2);
	    -moz-box-shadow: 0 5px 10px rgba(0,0,0,0.2);
	    box-shadow: 0 5px 10px rgba(0,0,0,0.2);
	    outline: none;
	    z-index: 10052;
	    margin: 0;
	}
</style>

<div class="row page-titles mx-0">
    <div class="col p-md-0">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="javascript:void(0)">Dashboard</a></li>
            <li class="breadcrumb-item active"><a href="javascript:void(0)">Time</a></li>
        </ol>
    </div>
</div>
<!-- row -->

<div class="container-fluid">
    <div class="row">
    	
    	<div class="col-lg-12">
    		<?php if(Session::has('success_message')): ?>
    		<div class="alert alert-success">
    		    <span class="glyphicon glyphicon-ok"></span>
    		    <?php echo session('success_message'); ?>


    		    <button type="button" class="close" data-dismiss="alert" aria-label="close">
    		        <span aria-hidden="true">&times;</span>
    		    </button>

    		</div>
    		<?php endif; ?>
    	    <div class="card">
    	        <div class="card-body">
    	            <div class="basic-form">
    	                <form action="<?php echo e(URL::to('admin/time/store')); ?>" method="post">
    	                	<?php echo csrf_field(); ?>
    	                	<div class="form-row">
    	                		<label class="col-sm-2 col-form-label"></label>
    	                	    <div class="form-group col-md-3" style="text-align: center;">
    	                	        <label><strong>Opening Hours</strong></label>
    	                	    </div>
    	                	    <div class="form-group col-md-3" style="text-align: center;">
    	                	        <label><strong>Closing Time</strong></label>
    	                	    </div>
                                <div class="form-group col-md-3" style="text-align: center;">
                                    <label><strong>Select the option if it is always closed</strong></label>
                                </div>
    	                	</div>
    	                	<?php $__currentLoopData = $gettime; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $time): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    	                    <div class="form-row">

                                <?php if($time->day == "Monday"): ?>
                                    <label class="col-sm-2 col-form-label">Monday</label>
                                <?php endif; ?>

                                <?php if($time->day == "Tuesday"): ?>
                                    <label class="col-sm-2 col-form-label">Tuesday</label>
                                <?php endif; ?>

                                <?php if($time->day == "Wednesday"): ?>
                                    <label class="col-sm-2 col-form-label">Wednesday</label>
                                <?php endif; ?>

                                <?php if($time->day == "Thursday"): ?>
                                    <label class="col-sm-2 col-form-label">Thursday</label>
                                <?php endif; ?>

                                <?php if($time->day == "Friday"): ?>
                                    <label class="col-sm-2 col-form-label">Friday</label>
                                <?php endif; ?>

                                <?php if($time->day == "Saturday"): ?>
                                    <label class="col-sm-2 col-form-label">Saturday</label>
                                <?php endif; ?>

                                <?php if($time->day == "Sunday"): ?>
                                    <label class="col-sm-2 col-form-label">Sunday</label>
                                <?php endif; ?>
    	                    	<input type="hidden" name="day[]" value="<?php echo e($time->day); ?>">

                                <?php if($time->always_close == '2'): ?>
                                    <div class="form-group col-md-3">
                                        <input type="text" class="form-control" placeholder="Opening Hours" id="open<?php echo e($time->day); ?>" name="open_time[]" value="<?php echo e($time->open_time); ?>">
                                    </div>
                                <?php else: ?>
                                    <div class="form-group col-md-3">
                                        <input type="text" class="form-control" placeholder="Opening Hours" id="open<?php echo e($time->day); ?>" name="open_time[]" value="Closed" readonly="">
                                    </div>
                                <?php endif; ?>

                                <?php if($time->always_close == '2'): ?>
                                    <div class="form-group col-md-3">
                                        <input type="text" class="form-control" placeholder="Closing Time" id="close<?php echo e($time->day); ?>" name="close_time[]" value="<?php echo e($time->close_time); ?>">
                                    </div>
                                <?php else: ?>
                                    <div class="form-group col-md-3">
                                        <input type="text" class="form-control" placeholder="Closing Time" id="close<?php echo e($time->day); ?>" name="close_time[]" value="Closed" readonly="">
                                    </div>
                                <?php endif; ?>

                                <div class="form-group col-md-3">
                                    <select class="form-control" name="always_close[]" id="always_close<?php echo e($time->day); ?>">
                                        <option value="">Select the option if it is always closed</option>
                                        <option value="1" <?php if($time->always_close == '1'): ?> selected <?php endif; ?>>Yes</option>
                                        <option value="2" <?php if($time->always_close == '2'): ?> selected <?php endif; ?>>No</option>
                                    </select>
                                </div>
    	                    </div>
    	                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    	                    <button type="submit" class="btn btn-primary">Save</button>
    	                </form>
    	            </div>
    	        </div>
    	    </div>
    	</div>

    </div>
<!-- #/ container -->
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="https://code.jquery.com/jquery-1.10.2.js"></script>

<!-- Updated JavaScript url -->
<script src="https://jonthornton.github.io/jquery-timepicker/jquery.timepicker.js" defer></script>
<script>
    $(document).ready(function () {
        $("#openMonday").timepicker();
        $("#closeMonday").timepicker();
        $("#openTuesday").timepicker();
        $("#closeTuesday").timepicker();
        $("#openWednesday").timepicker();
        $("#closeWednesday").timepicker();
        $("#openThursday").timepicker();
        $("#closeThursday").timepicker();
        $("#openFriday").timepicker();
        $("#closeFriday").timepicker();
        $("#openSaturday").timepicker();
        $("#closeSaturday").timepicker();
        $("#openSunday").timepicker();
        $("#closeSunday").timepicker();
    });
</script>
<?php echo $__env->make('theme.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/food/resources/views/time.blade.php ENDPATH**/ ?>