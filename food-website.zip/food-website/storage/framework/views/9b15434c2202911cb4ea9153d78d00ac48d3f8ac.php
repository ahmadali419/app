<?php echo $__env->make('front.theme.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section class="favourite">
    <div class="container">
        <h2 class="sec-head">Privacy Policy</h2>
        <div class="row">
            <?php echo $getprivacypolicy->privacypolicy_content; ?>

        </div>
    </div>
</section>

<?php echo $__env->make('front.theme.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/food/resources/views/front/privacy.blade.php ENDPATH**/ ?>