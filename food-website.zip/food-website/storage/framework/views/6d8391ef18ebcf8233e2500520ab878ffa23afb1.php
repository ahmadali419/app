<?php echo $__env->make('front.theme.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section class="product-prev-sec product-list-sec">
    <div class="container">
        <div class="product-rev-wrap">
            <div class="cat-product search-product">
                <div class="cart-pro-head">
                    <h2 class="sec-head">Our Quality Food</h2>
                    <div class="btn-wrap" data-toggle="buttons">
                        <label id="list" class="btn">
                            <input type="radio" name="layout" id="layout1"> <i class="fas fa-list"></i>
                        </label>
                        <label id="grid" class="btn active">
                            <input type="radio" name="layout" id="layout2" checked> <i class="fas fa-th"></i>
                        </label>
                    </div>
                </div>
                <div class="row">
                    <?php $__currentLoopData = $getitem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-xl-4 col-md-6">
                        <div class="pro-box">
                            <div class="pro-img">
                                <a href="<?php echo e(URL::to('product-details/'.$item->id)); ?>">
                                    <img src='<?php echo e($item["itemimage"]->image); ?>' alt="">
                                </a>
                                <?php if(Session::get('id')): ?>
                                    <?php if($item->is_favorite == 1): ?>
                                        <i class="fas fa-heart i"></i>
                                    <?php else: ?>
                                        <i class="fal fa-heart i" onclick="MakeFavorite('<?php echo e($item->id); ?>','<?php echo e(Session::get('id')); ?>')"></i>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                            <div class="product-details-wrap">
                                <div class="product-details">
                                    <a href="<?php echo e(URL::to('product-details/'.$item->id)); ?>">
                                        <h4><?php echo e($item->item_name); ?></h4>
                                    </a>
                                    <p class="pro-pricing"><?php echo env('CURRENCY'); ?><?php echo e(number_format($item->item_price, 2)); ?></p>
                                </div>
                                <div class="product-details">
                                    <p><?php echo e(Str::limit($item->item_description, 60)); ?></p>
                                    <!-- <?php if(Session::get('id')): ?>
                                        <button class="btn" onclick="AddtoCart('<?php echo e($item->id); ?>','<?php echo e(Session::get('id')); ?>')">Add to Cart</button>
                                    <?php else: ?>
                                        <a class="btn" href="<?php echo e(URL::to('/signin')); ?>">Add to Cart</a>
                                    <?php endif; ?> -->
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php echo $getitem->appends(request()->input())->links(); ?>

            </div>
        </div>
    </div>
</section>

<?php echo $__env->make('front.theme.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/food/resources/views/front/search.blade.php ENDPATH**/ ?>