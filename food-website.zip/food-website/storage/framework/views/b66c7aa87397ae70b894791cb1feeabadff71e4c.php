<script src="<?php echo asset('public/assets/plugins/common/common.min.js'); ?>"></script>
<script src="<?php echo asset('public/assets/js/custom.min.js'); ?>"></script>
<script src="<?php echo asset('public/assets/js/settings.js'); ?>"></script>
<script src="<?php echo asset('public/assets/js/gleek.js'); ?>"></script>
<script src="<?php echo asset('public/assets/js/styleSwitcher.js'); ?>"></script>

<!-- Circle progress -->
<script src="<?php echo asset('public/assets/plugins/circle-progress/circle-progress.min.js'); ?>"></script>
<!-- Datamap -->
<script src="<?php echo asset('public/assets/plugins/d3v3/index.js'); ?>"></script>
<script src="<?php echo asset('public/assets/plugins/topojson/topojson.min.js'); ?>"></script>
<!-- Morrisjs -->
<script src="<?php echo asset('public/assets/plugins/raphael/raphael.min.js'); ?>"></script>
<script src="<?php echo asset('public/assets/plugins/morris/morris.min.js'); ?>"></script>
<!-- Pignose Calender -->
<script src="<?php echo asset('public/assets/plugins/moment/moment.min.js'); ?>"></script>
<script src="<?php echo asset('public/assets/plugins/pg-calendar/js/pignose.calendar.min.js'); ?>"></script>
<!-- ChartistJS -->
<script src="<?php echo asset('public/assets/plugins/chartist/js/chartist.min.js'); ?>"></script>
<script src="<?php echo asset('public/assets/plugins/chartist-plugin-tooltips/js/chartist-plugin-tooltip.min.js'); ?>"></script>

<script src="<?php echo asset('public/assets/plugins/sweetalert/js/sweetalert.min.js'); ?>"></script>
<script src="<?php echo asset('public/assets/plugins/sweetalert/js/sweetalert.init.js'); ?>"></script>

<script src="<?php echo asset('public/assets/plugins/tables/js/jquery.dataTables.min.js'); ?>"></script>
<script src="<?php echo asset('public/assets/plugins/tables/js/datatable/dataTables.bootstrap4.min.js'); ?>"></script>
<script src="<?php echo asset('public/assets/plugins/tables/js/datatable-init/datatable-basic.min.js'); ?>"></script>
<?php echo $__env->yieldContent('script'); ?><?php /**PATH /var/www/html/food/resources/views/theme/script.blade.php ENDPATH**/ ?>