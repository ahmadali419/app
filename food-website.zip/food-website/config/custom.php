<?php

return [
	'razor_key' => 'rzp_test_W8Uw4npxq50oKV',
	'razor_secret' => 's6TcLfgcqXXa5mw1uGaMuOpE'
];